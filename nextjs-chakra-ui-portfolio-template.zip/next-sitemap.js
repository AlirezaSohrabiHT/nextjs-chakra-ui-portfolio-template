module.exports = {
  siteUrl: "https://mework.ir",
  generateRobotsTxt: true,
};
