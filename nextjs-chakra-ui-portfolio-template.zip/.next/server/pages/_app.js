"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5354:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "next-seo"
var external_next_seo_ = __webpack_require__(6641);
;// CONCATENATED MODULE: ./src/theme/index.jsx

const styles = {
    global: {
        "html, body": {
            fontSize: "18px"
        }
    }
};
const fonts = {
    heading: "Poppins, -apple-system",
    body: "Poppins, -apple-system"
};
const theme = (0,react_.extendTheme)({
    styles,
    fonts
});
/* harmony default export */ const src_theme = (theme);

// EXTERNAL MODULE: ./config.js
var config = __webpack_require__(1838);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./src/components/UI/logo.jsx



const Logo = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        href: "/",
        passHref: true,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.chakra.a, {
            fontSize: "2rem",
            fontWeight: "700",
            children: "Mework.ir"
        })
    }));
};
/* harmony default export */ const logo = (Logo);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "hamburger-react"
const external_hamburger_react_namespaceObject = require("hamburger-react");
;// CONCATENATED MODULE: ./src/components/UI/hamburgerMenu.jsx



const HamburgerMenu = ({ toggled , toggle  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        display: {
            lg: "none"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_hamburger_react_namespaceObject.Turn, {
            hideOutline: false,
            label: "hamburger menu",
            size: 25,
            toggled: toggled,
            toggle: toggle,
            direction: "right"
        })
    }));
};
/* harmony default export */ const hamburgerMenu = (HamburgerMenu);

;// CONCATENATED MODULE: external "@chakra-ui/icons"
const icons_namespaceObject = require("@chakra-ui/icons");
;// CONCATENATED MODULE: ./src/components/UI/colorModeToggle.jsx



const DarkModeToggle = ()=>{
    const { colorMode , toggleColorMode  } = (0,react_.useColorMode)();
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
        "aria-label": colorMode === "light" ? "switch to dark mode" : "switch to light mode",
        ml: {
            lg: "6"
        },
        variant: "ghost",
        _hover: {
            color: "black",
            bgColor: "white"
        },
        onClick: toggleColorMode,
        children: colorMode === "light" ? /*#__PURE__*/ jsx_runtime_.jsx(icons_namespaceObject.MoonIcon, {
            name: "moon-icon"
        }) : /*#__PURE__*/ jsx_runtime_.jsx(icons_namespaceObject.SunIcon, {
            name: "sun-icon"
        })
    }));
};
/* harmony default export */ const colorModeToggle = (DarkModeToggle);

;// CONCATENATED MODULE: ./src/components/header/navbar.jsx






const Navbar = ()=>{
    const { 0: isOpen , 1: setIsOpen  } = (0,external_react_.useState)(false);
    const bg = (0,react_.useColorModeValue)("gray.200", "gray.300");
    const color = (0,react_.useColorModeValue)("black", "white");
    const closeMenu = ()=>{
        setIsOpen(false);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        as: "nav",
        display: "flex",
        flexDir: {
            base: "row-reverse",
            lg: "row"
        },
        alignItems: "center",
        fontWeight: "500",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(hamburgerMenu, {
                toggled: isOpen,
                toggle: setIsOpen
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.chakra.ul, {
                bg: {
                    base: bg,
                    lg: "transparent"
                },
                color: {
                    base: "black",
                    lg: color
                },
                display: {
                    base: isOpen ? "block" : "none",
                    lg: "flex"
                },
                position: {
                    base: "absolute",
                    lg: "static"
                },
                top: "5rem",
                left: "5%",
                right: "5%",
                rounded: {
                    base: "lg",
                    lg: "none"
                },
                py: {
                    base: "2",
                    lg: "0"
                },
                px: {
                    base: "4",
                    lg: "0"
                },
                alignItems: {
                    lg: "center"
                },
                boxShadow: {
                    base: "xl",
                    lg: "none"
                },
                zIndex: "2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.chakra.li, {
                        listStyleType: "none",
                        px: {
                            lg: "8"
                        },
                        py: {
                            base: "3",
                            lg: "0"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                onClick: closeMenu,
                                children: "Home"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.chakra.li, {
                        listStyleType: "none",
                        px: {
                            lg: "8"
                        },
                        py: {
                            base: "3",
                            lg: "0"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/blog",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                onClick: closeMenu,
                                children: "Blog"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(colorModeToggle, {})
        ]
    }));
};
/* harmony default export */ const navbar = (Navbar);

;// CONCATENATED MODULE: ./src/components/header/index.jsx





const Header = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        as: "header",
        boxShadow: "md",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            h: "4rem",
            px: [
                4,
                6,
                10,
                14,
                20
            ],
            maxW: config/* MAX_WIDTH */.d,
            mx: "auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(logo, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(navbar, {})
            ]
        })
    }));
};
/* harmony default export */ const header = (Header);

;// CONCATENATED MODULE: external "react-icons/fa"
const fa_namespaceObject = require("react-icons/fa");
;// CONCATENATED MODULE: ./src/components/footer.jsx




// Fell free to add your social media accounts!
const socialAccounts = [
    {
        icon: fa_namespaceObject.FaGithub,
        path: "https://github.com/AlirezaSohrabiHT",
        title: "Github"
    },
    {
        icon: fa_namespaceObject.FaLinkedin,
        path: "https://www.linkedin.com/in/alireza-sohrabi-ht/",
        title: "Linkedin"
    },
    {
        icon: fa_namespaceObject.FaInstagram,
        path: "https://www.instagram.com/alireza.sohrabi.ht/profilecard/?igsh=MWZuN25raWFzaGFoMQ==",
        title: "Instagram"
    }, 
];
const Footer = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        as: "footer",
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDir: "column",
            textAlign: "center",
            minH: "4rem",
            px: [
                4,
                6,
                10,
                14,
                20
            ],
            maxW: config/* MAX_WIDTH */.d,
            mx: "auto",
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                py: "2",
                children: socialAccounts.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                        href: item.path,
                        "aria-label": item.title,
                        mx: "2",
                        _focus: {
                            outline: "none"
                        },
                        isExternal: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            "aria-label": item.title,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                as: item.icon,
                                w: "6",
                                h: "6"
                            })
                        })
                    }, index)
                )
            })
        })
    }));
};
/* harmony default export */ const footer = (Footer);

;// CONCATENATED MODULE: ./src/layouts/global.jsx





const Layout = ({ children  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                as: "main",
                px: [
                    4,
                    6,
                    10,
                    14,
                    20
                ],
                maxW: config/* MAX_WIDTH */.d,
                mx: "auto",
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
        ]
    })
;
/* harmony default export */ const global = (Layout);

;// CONCATENATED MODULE: ./next-seo.config.js

/* harmony default export */ const next_seo_config = ({
    titleTemplate: `%s | ${config/* seo.title */.$K.title}`,
    openGraph: {
        type: "website",
        locale: "en_US",
        url: config/* seo.canonical */.$K.canonical,
        site_name: config/* seo.title */.$K.title
    }
});

;// CONCATENATED MODULE: ./src/pages/_app.jsx











const MyApp = ({ Component , pageProps  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_next_seo_.DefaultSeo, {
                ...next_seo_config
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.ChakraProvider, {
                theme: src_theme,
                children: /*#__PURE__*/ jsx_runtime_.jsx(global, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                })
            })
        ]
    })
;
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,676,664,838], () => (__webpack_exec__(5354)));
module.exports = __webpack_exports__;

})();